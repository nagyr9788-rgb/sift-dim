#!/usr/bin/env python3
"""Converts the real "Mielon's The Sift" Fabric JAR into:
  nexo/                     -> copy into plugins/Nexo/  (items/*.yml + pack/assets/the_sift/**)
  src/main/resources/...    -> datapack template, structures (json), mob bone data, mobs.yml
Usage: python3 tools/convert.py <the_sift.jar> [project_dir]
"""
import sys, os, re, json, glob, shutil, zipfile, math, gzip
import yaml, nbtlib

JAR = sys.argv[1]
PROJ = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(PROJ, "build", "jar_extract")
NEXO = os.path.join(PROJ, "nexo")
RES = os.path.join(PROJ, "src", "main", "resources")
PACK = os.path.join(NEXO, "pack", "assets", "the_sift")

shutil.rmtree(WORK, ignore_errors=True); os.makedirs(WORK)
zipfile.ZipFile(JAR).extractall(WORK)
A = os.path.join(WORK, "assets", "the_sift")
D = os.path.join(WORK, "data", "the_sift")
def jl(p): return json.load(open(p, encoding="utf8"))
def jw(p, o):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    json.dump(o, open(p, "w", encoding="utf8"), indent=1)
lang = jl(os.path.join(A, "lang", "en_us.json"))
def name_of(i):
    return lang.get("block.the_sift." + i) or lang.get("item.the_sift." + i) or i.replace("_", " ").title()

# ---------------------------------------------------------------- 1. resource pack assets
shutil.rmtree(NEXO, ignore_errors=True)
for sub in ("textures", "models", "sounds", "particles", "equipment", "lang"):
    if os.path.isdir(os.path.join(A, sub)):
        shutil.copytree(os.path.join(A, sub), os.path.join(PACK, sub))
shutil.copy(os.path.join(A, "sounds.json"), os.path.join(PACK, "sounds.json"))
# shaders deliberately skipped (Fabric core-shader overrides can break vanilla rendering)

# ---------------------------------------------------------------- 2. block table
# (id, kind, hardness(vanilla analogue), best_tool, minimal_type, sound)
CUBES = {
 "siftslate": (3.0,"PICKAXE","WOODEN","deepslate"), "cobbled_siftslate": (3.5,"PICKAXE","WOODEN","deepslate"),
 "siftslate_bricks": (3.5,"PICKAXE","WOODEN","deepslate_bricks"), "chiseled_siftslate": (3.5,"PICKAXE","WOODEN","deepslate_bricks"),
 "reinforced_siftslate": (3600000,None,None,"deepslate"), "siftslate_growth": (3.0,"PICKAXE","WOODEN","deepslate"),
 "siftslate_coal_ore": (4.5,"PICKAXE","WOODEN","deepslate"), "siftslate_diamond_ore": (4.5,"PICKAXE","IRON","deepslate"),
 "siftslate_emerald_ore": (4.5,"PICKAXE","IRON","deepslate"), "siftslate_charoite_ore": (4.5,"PICKAXE","STONE","deepslate"),
 "siftslate_siftite_ore": (4.5,"PICKAXE","IRON","deepslate"), "sift_rubble": (0.6,"SHOVEL",None,"gravel"),
 "ichor_glass": (0.3,None,None,"glass"), "ichor_snow_block": (0.2,"SHOVEL",None,"snow"),
 "healthy_sculk": (0.2,"HOE",None,"sculk"), "dry_healthy_sculk": (0.2,"HOE",None,"sculk"),
 "soul_block": (0.35,"SHOVEL",None,"soul_soil"), "overgrown_willow_planks": (2.0,"AXE",None,"wood"),
 "overgrown_willow_foliage": (0.7,"HOE",None,"nether_wart"),
}
LOGS = {"overgrown_willow_log": "overgrown_willow_log", "stripped_overgrown_willow_log": "stripped_overgrown_willow_log",
        "overgrown_willow_wood": None, "stripped_overgrown_willow_wood": None}
PLANTS = ["siftslate_stalks","overgrown_stalks","overgrown_chard","overgrown_fronds","overgrown_lotus","sunburst_plant",
          "whisperbloom","sculkflower","healthy_sculk_sprouts","dry_healthy_sculk_sprouts","overgrown_willow_sapling",
          "siftslate_hanging_roots","overgrown_hanging_roots"]
SOUND = {"deepslate":"block.deepslate","deepslate_bricks":"block.deepslate_bricks","gravel":"block.gravel","glass":"block.glass",
         "snow":"block.snow","sculk":"block.sculk","soul_soil":"block.soul_soil","wood":"block.wood","nether_wart":"block.nether_wart"}

def loot_for(bid):
    p = os.path.join(D, "loot_table", "blocks", bid + ".json")
    if not os.path.exists(p): return None
    items = []
    def walk(n, silk=False):
        if isinstance(n, dict):
            c = json.dumps(n.get("condition", ""))
            s = silk or "silk_touch" in c or "can_silk_touch" in c
            if n.get("type") == "minecraft:item" and "name" in n:
                items.append((n["name"], s, "fortune" in json.dumps(n.get("modifier", ""))))
            for v in n.values(): walk(v, s)
        elif isinstance(n, list):
            for v in n: walk(v, silk)
    walk(jl(p)); return items

def drop_cfg(bid, tool, mt):
    d = {"silktouch": False, "fortune": False}
    if mt: d["minimal_type"] = mt
    if tool: d["best_tool"] = tool
    loots = []
    for name, silk, fort in loot_for(bid) or [(("the_sift:" + bid), False, False)]:
        if silk: d["silktouch"] = True; continue
        if fort: d["fortune"] = True
        ns, i = name.split(":")
        if ns == "the_sift":
            if i == bid and d["silktouch"]: continue
            loots.append({"nexo_item": i})
        else: loots.append({"minecraft_type": i.upper(), "amount": 1})
    if loots: d["loots"] = loots
    return d

variation = {"n": 0, "s": 0}
def nv(kind):
    variation[kind] += 1; return variation[kind]

blocks_yml, plants_yml, ids_nexo_block = {}, {}, {}
for bid, (hard, tool, mt, snd) in CUBES.items():
    v = nv("n")
    blocks_yml[bid] = {"itemname": name_of(bid), "material": "PAPER",
        "Pack": {"generate_model": False, "model": "the_sift:block/" + bid},
        "Mechanics": {"custom_block": {"type": "NOTEBLOCK", "custom_variation": v, "model": "the_sift:block/" + bid,
            "hardness": hard, "drop": drop_cfg(bid, tool, mt),
            "block_sounds": {"place_sound": SOUND[snd] + ".place", "break_sound": SOUND[snd] + ".break",
                             "step_sound": SOUND[snd] + ".step", "hit_sound": SOUND[snd] + ".hit"}}}}
    ids_nexo_block[bid] = ("NOTEBLOCK", v)
# sonorous deepslate: two states (horn / note) -> two variations; both drop the base item
for mode in ("horn", "note"):
    bid = "sonorous_deepslate" if mode == "note" else "sonorous_deepslate_horn"
    v = nv("n")
    blocks_yml[bid] = {"itemname": name_of("sonorous_deepslate"), "material": "PAPER",
        "Pack": {"generate_model": False, "model": "the_sift:block/sonorous_deepslate_" + mode},
        "Mechanics": {"custom_block": {"type": "NOTEBLOCK", "custom_variation": v, "model": "the_sift:block/sonorous_deepslate_" + mode,
            "hardness": 55, "drop": {"silktouch": True, "best_tool": "PICKAXE", "minimal_type": "IRON",
                                     "loots": [{"nexo_item": "sonorous_deepslate"}]}}}}
    ids_nexo_block[bid] = ("NOTEBLOCK", v)
# logs (directional LOG = 3 variations each)
for bid in LOGS:
    side = "the_sift:block/" + bid
    blocks_yml[bid] = {"itemname": name_of(bid), "material": "PAPER",
        "Pack": {"generate_model": False, "model": side},
        "Mechanics": {"custom_block": {"type": "NOTEBLOCK", "custom_variation": nv("n"), "model": side, "hardness": 2.0,
            "directional": {"type": "LOG",
                "y_block": {"model": side, "custom_variation": nv("n")},
                "x_block": {"model": side + "_horizontal" if os.path.exists(os.path.join(A,"models/block",bid+"_horizontal.json")) else side, "custom_variation": nv("n")},
                "z_block": {"model": side + "_horizontal" if os.path.exists(os.path.join(A,"models/block",bid+"_horizontal.json")) else side, "custom_variation": nv("n")}},
            "drop": {"silktouch": False, "best_tool": "AXE", "loots": [{"nexo_item": bid}]}}}}
    ids_nexo_block[bid] = ("NOTEBLOCK_LOG", blocks_yml[bid]["Mechanics"]["custom_block"]["custom_variation"])
for bid in PLANTS:
    v = nv("s")
    plants_yml[bid] = {"itemname": name_of(bid), "material": "PAPER",
        "Pack": {"generate_model": False, "model": "the_sift:block/" + bid},
        "Mechanics": {"custom_block": {"type": "STRINGBLOCK", "custom_variation": v, "model": "the_sift:block/" + bid,
            "hardness": 0, "drop": {"loots": [{"nexo_item": bid}]}}}}
    ids_nexo_block[bid] = ("STRINGBLOCK", v)

# ---------------------------------------------------------------- 3. plain items
ITEM_MATERIAL = {"siftite_sword":"NETHERITE_SWORD","siftite_axe":"NETHERITE_AXE","siftite_pickaxe":"NETHERITE_PICKAXE",
  "siftite_shovel":"NETHERITE_SHOVEL","siftite_hoe":"NETHERITE_HOE","siftite_spear":"NETHERITE_SPEAR",
  "siftite_helmet":"NETHERITE_HELMET","siftite_chestplate":"NETHERITE_CHESTPLATE","siftite_leggings":"NETHERITE_LEGGINGS",
  "siftite_boots":"NETHERITE_BOOTS","raw_sifter_meat":"BEEF","cooked_sifter_meat":"COOKED_BEEF","ichor_bucket":"WATER_BUCKET",
  "ichor_bottle":"POTION","ichor_snowball":"SNOWBALL","music_disc_rift":"MUSIC_DISC_13","music_disc_wellspring":"MUSIC_DISC_13",
  "overgrown_willow_boat":"OAK_BOAT","overgrown_willow_chest_boat":"OAK_CHEST_BOAT","sculkflower_seeds":"WHEAT_SEEDS",
  "siftite_upgrade_smithing_template":"NETHERITE_UPGRADE_SMITHING_TEMPLATE"}
items_yml = {}
placed = set(blocks_yml) | set(plants_yml)
all_items = sorted(os.path.splitext(f)[0] for f in os.listdir(os.path.join(A, "items")))
SKIP = re.compile(r"_trim$|_spawn_egg$|^sift_portal$|^ichor_cauldron$")
for iid in all_items:
    if iid in placed or SKIP.search(iid): continue
    mpath = os.path.join(A, "models/item", iid + ".json")
    has_item_model = os.path.exists(mpath)
    model = ("the_sift:item/" + iid) if has_item_model else ("the_sift:block/" + iid)
    if not has_item_model and not os.path.exists(os.path.join(A, "models/block", iid + ".json")): continue
    cfg = {"itemname": name_of(iid), "material": ITEM_MATERIAL.get(iid, "PAPER"),
           "Pack": {"generate_model": False, "model": model}}
    if iid.startswith("siftite_") and iid.split("_")[1] in ("helmet","chestplate","leggings","boots"):
        slot = {"helmet":"HEAD","chestplate":"CHEST","leggings":"LEGS","boots":"FEET"}[iid.split("_")[1]]
        cfg["Components"] = {"equippable": {"slot": slot, "asset_id": "the_sift:siftite"}}
    items_yml[iid] = cfg
# spawn eggs -> plain items used by the plugin
EGG_MOB = {}
for iid in all_items:
    if iid.endswith("_spawn_egg"):
        m = iid[:-len("_spawn_egg")]; EGG_MOB[m] = iid
        items_yml[iid] = {"itemname": name_of(iid), "material": "PAPER",
            "Pack": {"generate_model": False, "model": "the_sift:item/" + iid}}
# portal item / sift rift item
items_yml["sift_portal"] = {"itemname": "Sift Portal (debug)", "material": "PAPER", "Pack": {"generate_model": False, "model": "the_sift:item/sift_portal"}}

# ---------------------------------------------------------------- 4. mobs: bones -> Nexo items + bone data
MOBS = ["blub","sifter","singer","echo_golem","rift"]
TEX = {"blub":"blub","sifter":"sifter","singer":"singer","echo_golem":"echo_golem","rift":"rift/sift"}
mob_items = {}
mob_data = {}
for mob in MOBS:
    geo = jl(os.path.join(A, "geckolib/models/entity", mob + ".geo.json"))["minecraft:geometry"][0]
    tw, th = geo["description"]["texture_width"], geo["description"]["texture_height"]
    bones = geo["bones"]
    ext = 0
    for b in bones:
        pv = b.get("pivot", [0,0,0])
        for c in b.get("cubes", []):
            for k in range(3):
                ext = max(ext, abs(c["origin"][k]-pv[k]), abs(c["origin"][k]+c["size"][k]-pv[k]))
    s = 1.0 if ext <= 20 else 20.0/ext
    bd = []
    for b in bones:
        pv = b.get("pivot", [0,0,0]); elems = []
        for c in b.get("cubes", []):
            o, sz = c["origin"], c["size"]; inf = c.get("inflate", 0)
            fr = [(o[k]-inf-pv[k])*s+8 for k in range(3)]
            to = [(o[k]+sz[k]+inf-pv[k])*s+8 for k in range(3)]
            uv = c.get("uv", [0,0])
            def f(u0,v0,u1,v1): return {"uv":[u0*16/tw, v0*16/th, u1*16/tw, v1*16/th], "texture":"#0"}
            if isinstance(uv, dict):
                faces = {}
                for face, jf in (("north","north"),("east","east"),("south","south"),("west","west"),("up","up"),("down","down")):
                    if face in uv:
                        fu = uv[face]; (u,v),(w,h) = fu["uv"], fu["uv_size"]
                        faces[jf] = f(u,v,u+w,v+h)
            else:
                u,v = uv; sx,sy,szz = sz
                faces = {"north": f(u+szz, v+szz, u+szz+sx, v+szz+sy), "east": f(u, v+szz, u+szz, v+szz+sy),
                         "south": f(u+2*szz+sx, v+szz, u+2*szz+2*sx, v+szz+sy), "west": f(u+szz+sx, v+szz, u+2*szz+sx, v+szz+sy),
                         "up": f(u+szz, v, u+szz+sx, v+szz), "down": f(u+szz+sx, v+szz, u+szz+2*sx, v)}
            el = {"from": fr, "to": to, "faces": faces}
            if "rotation" in c:
                r = c["rotation"]; ax = max(range(3), key=lambda k: abs(r[k]))
                cp = c.get("pivot", pv)
                el["rotation"] = {"angle": r[ax], "axis": "xyz"[ax], "origin": [(cp[k]-pv[k])*s+8 for k in range(3)]}
                if sum(1 for x in r if abs(x) > 1e-6) > 1: el["_note"] = "multi-axis rotation approximated"
            elems.append(el)
        entry = {"name": b["name"], "parent": b.get("parent"), "pivot": pv, "rot": b.get("rotation", [0,0,0]), "has_model": bool(elems)}
        bd.append(entry)
        if elems:
            for e in elems: e.pop("_note", None)
            mid = f"{mob}_{b['name']}"
            jw(os.path.join(PACK, "models/entity_bones", mob, b["name"] + ".json"),
               {"textures": {"0": "the_sift:entity/" + TEX[mob], "particle": "the_sift:entity/" + TEX[mob]}, "elements": elems,
                "display": {}})
            mob_items[mid] = {"itemname": f"{mob} / {b['name']} (model part)", "material": "PAPER",
                "Pack": {"generate_model": False, "model": f"the_sift:entity_bones/{mob}/{b['name']}"}}
    mob_data[mob] = {"scale": s, "bones": bd}
    shutil.copy(os.path.join(A, "geckolib/animations/entity", mob + ".animation.json"),
                os.path.join(RES, "mobs", mob + ".animation.json")) if os.makedirs(os.path.join(RES,"mobs"), exist_ok=True) is None else None
    jw(os.path.join(RES, "mobs", mob + ".bones.json"), mob_data[mob])
# dark sniffer has no GeckoLib model (reskinned sniffer): texture only
os.makedirs(os.path.join(RES,"mobs"), exist_ok=True)

# ---------------------------------------------------------------- 5. write Nexo item configs
def dump(name, d):
    p = os.path.join(NEXO, "items", name); os.makedirs(os.path.dirname(p), exist_ok=True)
    yaml.safe_dump(d, open(p, "w", encoding="utf8"), sort_keys=False, allow_unicode=True, width=200)
dump("the_sift_blocks.yml", blocks_yml); dump("the_sift_plants.yml", plants_yml)
dump("the_sift_items.yml", items_yml); dump("the_sift_mob_parts.yml", mob_items)
jw(os.path.join(RES, "nexo_blocks.json"), {k: {"type": t, "variation": v} for k, (t, v) in ids_nexo_block.items()})

# ---------------------------------------------------------------- 6. datapack template (custom bits stripped, blocks resolved by plugin)
DP = os.path.join(RES, "datapack_template")
shutil.rmtree(DP, ignore_errors=True)
for sub in ("dimension","dimension_type","timeline","world_clock","tags","worldgen"):
    if os.path.isdir(os.path.join(D, sub)): shutil.copytree(os.path.join(D, sub), os.path.join(DP, "data/the_sift", sub))
# minecraft-namespace data of the mod (tags etc.) is intentionally not shipped (would alter vanilla)
for p in glob.glob(os.path.join(DP, "data/the_sift/worldgen/feature/*.json")):
    o = jl(p)
    if o.get("type", "").startswith("the_sift:"):
        jw(p, {"type": "minecraft:no_op", "config": {}})
for p in glob.glob(os.path.join(DP, "data/the_sift/worldgen/biome/*.json")):
    s = open(p, encoding="utf8").read(); o = json.loads(s)
    att = o.get("attributes", {})
    att.pop("minecraft:visual/ambient_particles", None)
    spawns = att.get("minecraft:gameplay/natural_mob_spawns")
    if spawns:
        for cat, lst in spawns.get("spawns_by_category", {}).items():
            spawns["spawns_by_category"][cat] = [e for e in lst if not e["type"].startswith("the_sift:")]
    jw(p, o)
open(os.path.join(DP, "pack.mcmeta"), "w").write(json.dumps(
    {"pack": {"description": "The Sift (ported from Mielon's The Sift) - generated by the Sift plugin",
              "min_format": 94, "max_format": 999}}, indent=1))
tags_dir = os.path.join(DP, "data/the_sift/tags")
# block tags referencing custom blocks are fine to drop: nothing in the port reads them
# block tags kept (plugin maps custom blocks to stand-ins)
shutil.rmtree(os.path.join(tags_dir, "item"), ignore_errors=True)
shutil.rmtree(os.path.join(tags_dir, "fluid"), ignore_errors=True)

# ---------------------------------------------------------------- 7. structures -> JSON
def struct_json(src, dst):
    s = nbtlib.load(src)
    pal = []
    for p in s["palette"]:
        pal.append({"name": str(p["Name"]), "props": {str(k): str(v) for k, v in p.get("Properties", {}).items()}})
    blocks = [[int(b["pos"][0]), int(b["pos"][1]), int(b["pos"][2]), int(b["state"])] for b in s["blocks"]]
    jw(dst, {"size": [int(x) for x in s["size"]], "palette": pal, "blocks": blocks})
for src in glob.glob(os.path.join(D, "structure", "*.nbt")) + glob.glob(os.path.join(D, "structure", "overgrown_willow", "*.nbt")):
    rel = os.path.relpath(src, os.path.join(D, "structure"))[:-4].replace("/", "_")
    struct_json(src, os.path.join(RES, "structures", rel + ".json"))
print("blocks:", len(blocks_yml), "plants:", len(plants_yml), "items:", len(items_yml), "mob parts:", len(mob_items))
print("noteblock variations used:", variation["n"], "stringblock:", variation["s"])

# ---------------------------------------------------------------- 8. datapack file index (jar resources cannot be listed)
idx = []
for root, _, files in os.walk(DP):
    for f in files: idx.append(os.path.relpath(os.path.join(root, f), DP).replace(os.sep, "/"))
open(os.path.join(RES, "datapack_index.txt"), "w").write("\n".join(sorted(idx)))
