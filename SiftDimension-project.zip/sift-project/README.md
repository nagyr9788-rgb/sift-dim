# Sift Dimension - Paper/Purpur port of Mielon's "The Sift" (MC 26.3)

Generated from the real `the_sift-1.1.1-mc26.3-fabric.jar`. Everything below was read out of that JAR
(`tools/convert.py` re-creates it all: `python3 tools/convert.py the_sift.jar`; needs `pip install nbtlib pyyaml`).

## Requirements
Paper/Purpur **26.3** (Java 25), **Nexo** (noteblock + stringblock mechanics enabled - the default).

## Build
```
gradle bundle          # -> build/install/plugins/SiftDimension-1.0.0.jar  +  build/install/plugins/Nexo/...
```
(`paperApiVersion` / `nexoVersion` live in `gradle.properties`.)

## Install
1. Copy `nexo/` contents into `plugins/Nexo/` (`items/*.yml` and `pack/assets/the_sift/**`). `gradle bundle` does this layout for you.
2. Put `SiftDimension-1.0.0.jar` in `plugins/`.
3. Start the server. On first start the plugin asks Nexo for the exact block states of every Sift block and writes the
   ported worldgen datapack to `<world>/datapacks/the_sift_port/`. **Restart once** - the dimension `the_sift:the_sift` loads on the next boot.
4. `/sift tp` to enter/leave, `/sift reload`, `/sift give <nexo id>`, `/sift spawn <mob>`, `/sift datapack`.

## What is recreated (all from the JAR)
* **Dimension** - the original `dimension`, `dimension_type`, `noise_settings`, density functions, noises, carvers, 10 biomes,
  placed features, day/night timeline are shipped as-is. Custom block references are rewritten to the Nexo block states, so terrain,
  ores (coal/diamond/emerald/charoite/siftite), siftslate growth, sculk blobs, rubble, plants are natively Nexo blocks.
* **Portal** - frame of Reinforced Deepslate (<=23x23). Sonorous Deepslate consoles: sneak+use tunes a console to note 1-8,
  use plays it; playing `1 3 7 6 5 2 4 8` (SonorousConsoles.TARGET_SEQUENCE) within 16 blocks opens the portal, the reverse closes it.
  Entering teleports to the Sift (original `main_portal` structure is built on first entry); the structure's portal returns you.
* **Blocks/items** - 25 noteblock blocks (incl. 4 willow log/wood variants, 2 sonorous states), 13 stringblock plants, 50 items (siftite tools/armour with
  the original equipment asset, food, discs, ichor items...), 5 spawn eggs. Textures/models/sounds copied verbatim into the Nexo pack.
* **Mobs** (stats from the compiled classes): Sifter 40hp/10dmg/0.31, Blub 20hp/3dmg/0.30 (tameable), Dark Sniffer 40hp/7dmg/0.10,
  Echo Golem 34hp/0.23, Singer 20hp/0.27 (barters Soul Blocks using the original item pool). Models: each GeckoLib bone became a Nexo item model
  (`<mob>_<bone>`), shown as ItemDisplays and animated from the original `.animation.json`. Drops: Sifter raw/cooked meat (+looting), Dark Sniffer sculk.
* **Sift Rift** item/entity (travel between dimensions), natural spawns (80-tick check, 48-96 block ring, golem spacing 165, 2.5% new-chunk groups).

## Known gaps - please read
* **Not compiled here.** The sandbox cannot reach the Paper/Nexo Maven repos; the sources only passed a parse-level `javac` check
  (no syntax errors; API symbols unresolved). Expect to fix a few API-name mismatches on the first `gradle build`.
* Not tested in a running server. Nexo YAML keys follow the Nexo docs; `Pack.model` / `custom_block.model` using explicit model paths should be double-checked.
* 20 custom Java worldgen features are replaced with no-ops in the datapack (willow trees, ichor lakes, monoliths, arches, soul canyon, sniffer caves,
  abandoned portals, plant patches...). The structure data for willow trees/abandoned portals is converted (`structures/*.json`) but not yet wired to generation.
* Ichor (custom fluid) -> vanilla water; portal blocks are vanilla nether-portal blocks (purple swirl); stairs/slabs/walls/fences/doors/signs/shelf/cauldron/crop
  are not placeable (no core-Nexo mechanic) - their items/models are not registered.
* Dark Sniffer uses a vanilla Sniffer (original is a retexture of the vanilla model). Echo Golem soul missions, Singer summoning at the Ancient City,
  Blub tamed-skin, glow-masks and dynamic lights are not implemented. Bone-rotation sign conventions (GeckoLib -> Java) are unverified; expect to flip axes in `ModelRig`.
* datapack `pack.mcmeta` uses a wide `min_format/max_format`; adjust if 26.3 rejects it.
