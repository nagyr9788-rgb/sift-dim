package dev.sift;

import dev.nexomc.nexo.api.NexoItems;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public final class SiftCommand implements CommandExecutor, TabCompleter {
    private final SiftPlugin plugin;
    public SiftCommand(SiftPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) { s.sendMessage("/sift <tp|reload|give <id>|spawn <mob>|datapack>"); return true; }
        switch (a[0].toLowerCase()) {
            case "reload" -> { plugin.reload(); s.sendMessage("Sift reloaded."); }
            case "tp" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
                if (!plugin.isReady()) { s.sendMessage("Plugin still initialising (waiting for Nexo)."); return true; }
                plugin.portals().teleport(p);
            }
            case "give" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("/sift give <nexo id> [amount]"); return true; }
                var b = NexoItems.itemFromId(a[1]);
                if (b == null) { s.sendMessage("Unknown Nexo id " + a[1]); return true; }
                ItemStack st = b.build();
                st.setAmount(a.length > 2 ? Integer.parseInt(a[2]) : 1);
                p.getInventory().addItem(st);
            }
            case "spawn" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("/sift spawn <sifter|blub|dark_sniffer|echo_golem|singer|rift>"); return true; }
                if (!plugin.isReady() || !plugin.mobs().spawn(a[1], p.getLocation())) s.sendMessage("Cannot spawn " + a[1]);
            }
            case "datapack" -> {
                try {
                    var r = new dev.sift.world.DatapackInstaller(plugin, plugin.palette()).install();
                    s.sendMessage("Datapack: " + r + (r == dev.sift.world.DatapackInstaller.Result.WRITTEN ? " - restart the server." : ""));
                } catch (Exception e) { s.sendMessage("Failed: " + e); }
            }
            default -> s.sendMessage("Unknown subcommand.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return List.of("tp", "reload", "give", "spawn", "datapack");
        if (a.length == 2 && a[0].equalsIgnoreCase("spawn"))
            return List.of("sifter", "blub", "dark_sniffer", "echo_golem", "singer", "rift");
        return List.of();
    }
}
