package dev.sift.mob;

import com.google.gson.*;
import dev.nexomc.nexo.api.NexoItems;
import dev.sift.SiftPlugin;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.io.InputStreamReader;
import java.util.*;

/**
 * Shows a GeckoLib model as one ItemDisplay per bone (each bone is a Nexo item whose model was generated from the
 * original .geo.json) and plays the original .animation.json keyframes on them.
 */
public final class ModelRig {
    record Bone(String name, String parent, float[] pivot, float[] rot, boolean hasModel) {}
    record Data(float scale, List<Bone> bones, JsonObject anims) {}

    private static final Map<String, Data> CACHE = new HashMap<>();

    static Data data(SiftPlugin plugin, String model) {
        return CACHE.computeIfAbsent(model, m -> {
            try (var b = new InputStreamReader(plugin.getResource("mobs/" + m + ".bones.json"));
                 var a = new InputStreamReader(plugin.getResource("mobs/" + m + ".animation.json"))) {
                JsonObject bj = JsonParser.parseReader(b).getAsJsonObject();
                List<Bone> bones = new ArrayList<>();
                for (JsonElement e : bj.getAsJsonArray("bones")) {
                    JsonObject o = e.getAsJsonObject();
                    bones.add(new Bone(o.get("name").getAsString(),
                            o.get("parent").isJsonNull() ? null : o.get("parent").getAsString(),
                            vec(o.get("pivot")), vec(o.get("rot")), o.get("has_model").getAsBoolean()));
                }
                return new Data(bj.get("scale").getAsFloat(), bones,
                        JsonParser.parseReader(a).getAsJsonObject().getAsJsonObject("animations"));
            } catch (Exception ex) { throw new IllegalStateException("model " + m, ex); }
        });
    }

    private static float[] vec(JsonElement e) {
        float[] v = new float[3];
        if (e != null && e.isJsonArray()) for (int i = 0; i < 3 && i < e.getAsJsonArray().size(); i++) v[i] = num(e.getAsJsonArray().get(i));
        return v;
    }
    private static float num(JsonElement e) { try { return e.getAsFloat(); } catch (Exception ex) { return 0f; } }

    private final Data d;
    private final String mob;
    private final Entity owner;
    private final Map<String, ItemDisplay> displays = new LinkedHashMap<>();
    private final Map<String, Bone> byName = new HashMap<>();
    private String anim;
    private double time;
    private Location last;
    public boolean oneShotPlaying;

    public ModelRig(SiftPlugin plugin, String mob, Entity owner) {
        this.mob = mob; this.owner = owner; this.d = data(plugin, mob);
        for (Bone b : d.bones()) byName.put(b.name(), b);
        for (Bone b : d.bones()) {
            if (!b.hasModel()) continue;
            var builder = NexoItems.itemFromId(mob + "_" + b.name());
            if (builder == null) { plugin.getLogger().warning("Missing Nexo part " + mob + "_" + b.name()); continue; }
            ItemStack stack = builder.build();
            ItemDisplay disp = owner.getWorld().spawn(owner.getLocation(), ItemDisplay.class, id -> {
                id.setItemStack(stack);
                id.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
                id.setPersistent(false);
                id.setTeleportDuration(2);
                id.setInterpolationDuration(2);
                id.setViewRange(1.5f);
                id.setBrightness(null);
            });
            displays.put(b.name(), disp);
        }
        last = owner.getLocation();
    }

    public void play(String animation, boolean restart) {
        if (animation == null) return;
        if (!animation.equals(anim) || restart) { anim = animation; time = 0; }
    }
    public String current() { return anim; }

    public boolean isAnimationDone() {
        JsonObject a = anims(anim);
        return a == null || time >= a.get("animation_length").getAsDouble();
    }

    private JsonObject anims(String name) {
        return name != null && d.anims().has(name) ? d.anims().getAsJsonObject(name) : null;
    }

    /** Horizontal movement speed in blocks/tick since the last update. */
    public double speed() {
        Location now = owner.getLocation();
        double s = last.getWorld() == now.getWorld() ? Math.hypot(now.getX() - last.getX(), now.getZ() - last.getZ()) : 0;
        return s;
    }

    public void update(double dtSeconds) {
        Location loc = owner.getLocation();
        time += dtSeconds;
        JsonObject a = anims(anim);
        double len = a != null && a.has("animation_length") ? a.get("animation_length").getAsDouble() : 0;
        double t = time;
        if (a != null && len > 0) {
            boolean loop = !a.has("loop") || (a.get("loop").isJsonPrimitive() && a.get("loop").getAsJsonPrimitive().isBoolean() && a.get("loop").getAsBoolean());
            t = loop ? time % len : Math.min(time, len);
        }
        Map<String, Matrix4f> world = new HashMap<>();
        Quaternionf root = new Quaternionf().rotateY((float) (-Math.toRadians(loc.getYaw()) + Math.PI));
        Matrix4f rootM = new Matrix4f().rotate(root);
        for (Bone b : d.bones()) {
            ItemDisplay disp = displays.get(b.name());
            if (disp == null || !disp.isValid()) continue;
            Matrix4f w = worldMatrix(b, a, t, world, rootM);
            Matrix4f m = new Matrix4f(w).translate(b.pivot()[0] / 16f, b.pivot()[1] / 16f, b.pivot()[2] / 16f).scale(1f / d.scale());
            disp.setTransformationMatrix(m);
            disp.setInterpolationDelay(0);
            disp.setInterpolationDuration(2);
            if (disp.getLocation().distanceSquared(loc) > 1e-4) disp.teleport(new Location(loc.getWorld(), loc.getX(), loc.getY(), loc.getZ()));
        }
        last = loc;
    }

    private Matrix4f worldMatrix(Bone b, JsonObject anim, double t, Map<String, Matrix4f> memo, Matrix4f rootM) {
        Matrix4f cached = memo.get(b.name());
        if (cached != null) return cached;
        Matrix4f parent = b.parent() != null && byName.containsKey(b.parent()) ? worldMatrix(byName.get(b.parent()), anim, t, memo, rootM) : rootM;
        float[] rot = b.rot().clone(), pos = new float[3];
        if (anim != null && anim.has("bones") && anim.getAsJsonObject("bones").has(b.name())) {
            JsonObject bo = anim.getAsJsonObject("bones").getAsJsonObject(b.name());
            float[] r = sample(bo.get("rotation"), t), p = sample(bo.get("position"), t);
            if (r != null) for (int i = 0; i < 3; i++) rot[i] += r[i];
            if (p != null) pos = p;
        }
        float px = b.pivot()[0] / 16f, py = b.pivot()[1] / 16f, pz = b.pivot()[2] / 16f;
        // Bedrock/GeckoLib -> Java axis conventions: x and y rotations are mirrored, x translation is mirrored
        Quaternionf q = new Quaternionf().rotateZ((float) Math.toRadians(rot[2])).rotateY((float) Math.toRadians(-rot[1])).rotateX((float) Math.toRadians(-rot[0]));
        Matrix4f local = new Matrix4f().translate(px - pos[0] / 16f, py + pos[1] / 16f, pz + pos[2] / 16f).rotate(q).translate(-px, -py, -pz);
        Matrix4f w = new Matrix4f(parent).mul(local);
        memo.put(b.name(), w);
        return w;
    }

    /** Linear keyframe sampling of a bedrock animation channel (const array or time->vector map). */
    static float[] sample(JsonElement ch, double t) {
        if (ch == null) return null;
        if (ch.isJsonArray()) return vec(ch);
        if (!ch.isJsonObject()) return null;
        TreeMap<Double, float[]> frames = new TreeMap<>();
        for (var e : ch.getAsJsonObject().entrySet()) {
            try {
                JsonElement v = e.getValue();
                if (v.isJsonObject()) v = v.getAsJsonObject().has("vector") ? v.getAsJsonObject().get("vector")
                        : v.getAsJsonObject().has("post") ? v.getAsJsonObject().get("post") : v;
                frames.put(Double.parseDouble(e.getKey()), vec(v));
            } catch (NumberFormatException ignored) { }
        }
        if (frames.isEmpty()) return null;
        var lo = frames.floorEntry(t); var hi = frames.ceilingEntry(t);
        if (lo == null) return hi.getValue();
        if (hi == null || lo.getKey().equals(hi.getKey())) return lo.getValue();
        float f = (float) ((t - lo.getKey()) / (hi.getKey() - lo.getKey()));
        float[] r = new float[3];
        for (int i = 0; i < 3; i++) r[i] = lo.getValue()[i] + (hi.getValue()[i] - lo.getValue()[i]) * f;
        return r;
    }

    public boolean alive() { return owner.isValid() && !displays.isEmpty(); }

    public void remove() { displays.values().forEach(Entity::remove); displays.clear(); }
}
