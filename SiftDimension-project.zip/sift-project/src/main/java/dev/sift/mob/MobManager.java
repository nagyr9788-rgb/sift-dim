package dev.sift.mob;

import dev.nexomc.nexo.api.NexoItems;
import dev.sift.SiftPlugin;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/** Custom Sift mobs: a vanilla carrier mob (invisible) + a ModelRig of Nexo model parts + original stats/drops/spawning. */
public final class MobManager implements Listener {
    private final SiftPlugin plugin;
    private final NamespacedKey tag;
    private final Map<UUID, ModelRig> rigs = new HashMap<>();
    private final Map<UUID, Long> attackCd = new HashMap<>();
    private final Map<UUID, Long> riftCd = new HashMap<>();
    private final Random rnd = new Random();
    private ConfigurationSection defs;

    public MobManager(SiftPlugin plugin) {
        this.plugin = plugin;
        this.tag = new NamespacedKey(plugin, "sift_mob");
        reloadDefs();
    }

    public void reloadDefs() { defs = plugin.mobConfig(); }

    public void start() {
        // animation / model update (2 ticks) and custom AI (10 ticks)
        new BukkitRunnable() { @Override public void run() { tickRigs(); } }.runTaskTimer(plugin, 2L, 2L);
        new BukkitRunnable() { @Override public void run() { tickAi(); tickRifts(); } }.runTaskTimer(plugin, 10L, 10L);
        long iv = plugin.getConfig().getLong("spawning.check-interval-ticks", 80);
        new BukkitRunnable() { @Override public void run() { naturalSpawns(); } }.runTaskTimer(plugin, iv, iv);
        for (World w : Bukkit.getWorlds()) for (Entity e : w.getEntities()) attachIfTagged(e);
    }

    public String keyOf(Entity e) { return e.getPersistentDataContainer().get(tag, PersistentDataType.STRING); }

    // ------------------------------------------------------------------ spawning
    public boolean spawn(String key, Location loc) {
        ConfigurationSection d = defs.getConfigurationSection(key);
        if (d == null) return false;
        Entity e;
        if (key.equals("rift")) {
            e = loc.getWorld().spawn(loc, Interaction.class, i -> {
                List<Double> hb = d.getDoubleList("hitbox");
                i.setInteractionWidth(hb.isEmpty() ? 4.25f : hb.get(0).floatValue());
                i.setInteractionHeight(hb.size() < 2 ? 4.25f : hb.get(1).floatValue());
                i.setResponsive(false);
            });
        } else {
            EntityType type = EntityType.valueOf(d.getString("base"));
            e = loc.getWorld().spawnEntity(loc, type);
            if (!(e instanceof LivingEntity le)) { e.remove(); return false; }
            applyStats(le, d);
        }
        e.getPersistentDataContainer().set(tag, PersistentDataType.STRING, key);
        attachIfTagged(e);
        return true;
    }

    private void set(LivingEntity e, Attribute a, double v) {
        AttributeInstance i = e.getAttribute(a);
        if (i != null) i.setBaseValue(v);
    }

    private void applyStats(LivingEntity e, ConfigurationSection d) {
        set(e, Attribute.MAX_HEALTH, d.getDouble("health", 20));
        e.setHealth(d.getDouble("health", 20));
        set(e, Attribute.MOVEMENT_SPEED, d.getDouble("speed", 0.25));
        if (d.contains("damage")) set(e, Attribute.ATTACK_DAMAGE, d.getDouble("damage"));
        if (d.contains("follow-range")) set(e, Attribute.FOLLOW_RANGE, d.getDouble("follow-range"));
        if (d.contains("knockback-resistance")) set(e, Attribute.KNOCKBACK_RESISTANCE, Math.min(1.0, d.getDouble("knockback-resistance")));
        List<Double> hb = d.getDoubleList("hitbox");
        AttributeInstance sc = e.getAttribute(Attribute.SCALE);
        if (hb.size() > 1 && sc != null) {
            double baseHeight = e.getHeight() / Math.max(0.0625, sc.getValue());   // height of the carrier mob at scale 1
            sc.setBaseValue(Math.max(0.0625, Math.min(16, hb.get(1) / baseHeight)));
        }
        e.setInvisible(true);
        e.setSilent(true);
        e.setRemoveWhenFarAway(false);
        e.setCanPickupItems(false);
        if (e.getEquipment() != null) e.getEquipment().clear();
    }

    private void attachIfTagged(Entity e) {
        String k = keyOf(e);
        if (k == null || rigs.containsKey(e.getUniqueId())) return;
        ConfigurationSection d = defs.getConfigurationSection(k);
        if (d == null || d.getString("model") == null || d.getString("model").equals("null")) return;
        try { rigs.put(e.getUniqueId(), new ModelRig(plugin, d.getString("model"), e)); }
        catch (Exception ex) { plugin.getLogger().warning("Rig for " + k + " failed: " + ex); }
        if (e instanceof LivingEntity le) { le.setInvisible(true); }
        if (k.equals("rift")) { var r = rigs.get(e.getUniqueId()); if (r != null) r.play("appear", true); }
    }

    @EventHandler public void onEntitiesLoad(EntitiesLoadEvent ev) { for (Entity e : ev.getEntities()) attachIfTagged(e); }

    // ------------------------------------------------------------------ ticking
    private void tickRigs() {
        for (Iterator<Map.Entry<UUID, ModelRig>> it = rigs.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next(); ModelRig rig = en.getValue();
            Entity e = Bukkit.getEntity(en.getKey());
            if (e == null || !e.isValid() || !rig.alive()) { rig.remove(); it.remove(); continue; }
            String key = keyOf(e);
            if (key == null) { rig.remove(); it.remove(); continue; }
            ConfigurationSection d = defs.getConfigurationSection(key);
            ConfigurationSection an = d == null ? null : d.getConfigurationSection("anim");
            if (an != null && !rig.oneShotPlaying) {
                String want = null;
                boolean sitting = e instanceof Sittable s && s.isSitting();
                boolean moving = rig.speed() > 0.01;
                if (sitting && an.contains("sit")) want = an.getString("sit");
                else if (moving && an.contains("move")) want = an.getString("move");
                else want = an.getString("idle", moving ? an.getString("move") : null);
                if (want != null) rig.play(want, false);
            }
            if (rig.oneShotPlaying && rig.isAnimationDone()) rig.oneShotPlaying = false;
            rig.update(0.1);
        }
    }

    private void tickAi() {
        long now = Bukkit.getCurrentTick();
        for (World w : Bukkit.getWorlds()) for (Mob m : w.getEntitiesByClass(Mob.class)) {
            String key = keyOf(m);
            if (key == null) continue;
            ConfigurationSection d = defs.getConfigurationSection(key);
            if (d == null || !"chase".equals(d.getString("ai"))) continue;
            double range = d.getDouble("follow-range", 24);
            Player best = null; double bd = range * range;
            for (Player p : w.getPlayers()) {
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) continue;
                double dd = p.getLocation().distanceSquared(m.getLocation());
                if (dd < bd) { bd = dd; best = p; }
            }
            if (best == null) continue;
            m.getPathfinder().moveTo(best, 1.0);
            double reach = Math.max(2.5, m.getWidth() / 2 + 1.5);
            if (bd <= reach * reach && now - attackCd.getOrDefault(m.getUniqueId(), -1000L) >= 20) {
                attackCd.put(m.getUniqueId(), now);
                best.damage(d.getDouble("damage", 4), m);
                Vector kb = best.getLocation().toVector().subtract(m.getLocation().toVector()).setY(0).normalize().multiply(0.6).setY(0.25);
                best.setVelocity(best.getVelocity().add(kb));
                triggerAttack(m, key);
            }
        }
    }

    private void triggerAttack(Entity m, String key) {
        ModelRig rig = rigs.get(m.getUniqueId());
        ConfigurationSection an = defs.getConfigurationSection(key + ".anim");
        if (rig != null && an != null && an.contains("attack")) { rig.oneShotPlaying = true; rig.play(an.getString("attack"), true); }
        m.getWorld().playSound(m.getLocation(), "the_sift:entity." + key + ".attack", SoundCategory.HOSTILE, 1f, 1f);
    }

    @EventHandler
    public void onDamageDealt(EntityDamageByEntityEvent e) {
        String key = keyOf(e.getDamager());
        if (key != null && !"chase".equals(defs.getString(key + ".ai"))) triggerAttack(e.getDamager(), key);
    }

    @EventHandler
    public void onHurt(EntityDamageEvent e) {
        String key = keyOf(e.getEntity());
        if (key == null || key.equals("rift")) return;
        e.getEntity().getWorld().playSound(e.getEntity().getLocation(), "the_sift:entity." + key + ".hurt", SoundCategory.NEUTRAL, 1f, 1f);
    }

    // ------------------------------------------------------------------ behaviour guards
    @EventHandler(priority = EventPriority.HIGH)
    public void onTarget(EntityTargetEvent e) {
        String key = keyOf(e.getEntity());
        if (key != null && "passive".equals(defs.getString(key + ".ai")) && e.getTarget() != null) e.setCancelled(true);
    }

    @EventHandler
    public void onTeleport(EntityTeleportEvent e) {
        String key = keyOf(e.getEntity());
        if (key != null && "passive".equals(defs.getString(key + ".ai"))) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ drops
    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        String key = keyOf(e.getEntity());
        if (key == null) return;
        e.getEntity().getWorld().playSound(e.getEntity().getLocation(), "the_sift:entity." + key + ".death", SoundCategory.NEUTRAL, 1f, 1f);
        ConfigurationSection d = defs.getConfigurationSection(key + ".drops");
        e.getDrops().clear();
        if (d == null) return;
        int amount = d.getInt("min", 1) + rnd.nextInt(d.getInt("max", 1) - d.getInt("min", 1) + 1);
        Player k = e.getEntity().getKiller();
        int loot = k == null ? 0 : k.getInventory().getItemInMainHand().getEnchantmentLevel(Enchantment.LOOTING);
        if (loot > 0 && d.getInt("looting-bonus-max", 0) > 0)
            for (int i = 0; i < loot; i++) amount += rnd.nextInt(d.getInt("looting-bonus-max") + 1);
        String item = d.getString("item");
        if (d.getBoolean("cooked-if-burning") && e.getEntity().getFireTicks() > 0) item = "cooked_sifter_meat";
        ItemStack st = stack(item);
        if (st == null) return;
        st.setAmount(Math.max(1, amount));
        e.getDrops().add(st);
    }

    private ItemStack stack(String id) {
        if (id == null) return null;
        if (id.startsWith("minecraft:")) {
            Material m = Material.matchMaterial(id);
            return m == null ? null : new ItemStack(m);
        }
        String nid = id.startsWith("nexo:") ? id.substring(5) : id;
        var b = NexoItems.itemFromId(nid);
        return b == null ? null : b.build();
    }

    private String nexoId(ItemStack s) { return s == null || s.getType().isAir() ? null : NexoItems.idFromItem(s); }

    // ------------------------------------------------------------------ interactions: spawn eggs, rift item, Singer barter, Blub taming
    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null) return;
        String id = nexoId(e.getItem());
        if (id == null) return;
        Location at = e.getClickedBlock().getRelative(e.getBlockFace()).getLocation().add(0.5, 0, 0.5);
        if (id.endsWith("_spawn_egg") && defs.contains(id.substring(0, id.length() - "_spawn_egg".length()))) {
            e.setCancelled(true);
            if (spawn(id.substring(0, id.length() - "_spawn_egg".length()), at) && e.getPlayer().getGameMode() != GameMode.CREATIVE) e.getItem().subtract();
        } else if (id.equals("sift_rift")) {
            e.setCancelled(true);
            at.add(0, 2, 0);
            if (spawn("rift", at) && e.getPlayer().getGameMode() != GameMode.CREATIVE) e.getItem().subtract();
        }
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        String key = keyOf(e.getRightClicked());
        if (key == null || e.getHand() != EquipmentSlot.HAND) return;
        ItemStack hand = e.getPlayer().getInventory().getItemInMainHand();
        String id = nexoId(hand);
        switch (key) {
            case "singer" -> {
                e.setCancelled(true);
                if (!"soul_block".equals(id)) return;
                String reward = pickBarter();
                ItemStack out = stack(reward.startsWith("nexo:") ? reward : "minecraft:" + reward.toLowerCase());
                if (out == null) return;
                if (e.getPlayer().getGameMode() != GameMode.CREATIVE) hand.subtract();
                Entity s = e.getRightClicked();
                Item drop = s.getWorld().dropItem(s.getLocation().add(0, 1.2, 0), out);
                drop.setVelocity(e.getPlayer().getEyeLocation().toVector().subtract(s.getLocation().toVector()).normalize().multiply(0.3));
                s.getWorld().playSound(s.getLocation(), "the_sift:entity.singer.happy", SoundCategory.NEUTRAL, 1f, 1f);
                ModelRig rig = rigs.get(s.getUniqueId());
                if (rig != null) { rig.oneShotPlaying = true; rig.play("receive_soul", true); }
            }
            case "echo_golem" -> e.setCancelled(true);
            case "blub" -> {
                if (id != null && e.getRightClicked() instanceof Tameable t && !t.isTamed()
                        && defs.getStringList("blub.tame-items").stream().anyMatch(x -> x.equals("nexo:" + id))) {
                    e.setCancelled(true);
                    if (e.getPlayer().getGameMode() != GameMode.CREATIVE) hand.subtract();
                    if (rnd.nextInt(3) == 0) { t.setTamed(true); t.setOwner(e.getPlayer()); }
                }
            }
            default -> { }
        }
    }

    private String pickBarter() {
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("singer-barter");
        int total = 0;
        for (String k : c.getKeys(false)) total += c.getInt(k);
        int r = rnd.nextInt(Math.max(1, total));
        for (String k : c.getKeys(false)) { r -= c.getInt(k); if (r < 0) return k; }
        return "IRON_BLOCK";
    }

    // ------------------------------------------------------------------ Sift Rift: touch to travel between the Overworld and the Sift
    private void tickRifts() {
        long now = Bukkit.getCurrentTick();
        World sift = plugin.siftWorld();
        if (sift == null) return;
        for (World w : Bukkit.getWorlds()) for (Interaction i : w.getEntitiesByClass(Interaction.class)) {
            if (!"rift".equals(keyOf(i))) continue;
            for (Player p : w.getPlayers()) {
                if (p.getGameMode() == GameMode.SPECTATOR) continue;
                if (p.getLocation().distanceSquared(i.getLocation().add(0, 2, 0)) > 6.25) continue;
                if (now - riftCd.getOrDefault(p.getUniqueId(), -1000L) < 100) continue;
                riftCd.put(p.getUniqueId(), now);
                World dest = w.equals(sift) ? Bukkit.getWorlds().get(0) : sift;
                int x = i.getLocation().getBlockX(), z = i.getLocation().getBlockZ();
                dest.getChunkAtAsync(x >> 4, z >> 4).thenAccept(c -> Bukkit.getScheduler().runTask(plugin, () -> {
                    int y = dest.getHighestBlockYAt(x, z) + 1;
                    Location exit = new Location(dest, x + 0.5, y + 2, z + 0.5);
                    boolean has = dest.getEntitiesByClass(Interaction.class).stream()
                            .anyMatch(o -> "rift".equals(keyOf(o)) && o.getLocation().distanceSquared(exit) < 64);
                    if (!has) spawn("rift", exit);
                    p.teleportAsync(exit.clone().add(3, -2, 0));
                    dest.playSound(exit, "the_sift:entity.rift.appear", SoundCategory.AMBIENT, 1f, 1f);
                }));
            }
        }
    }

    // ------------------------------------------------------------------ natural spawning
    @EventHandler
    public void onNewChunk(ChunkLoadEvent e) {
        World sift = plugin.siftWorld();
        if (!e.isNewChunk() || sift == null || !e.getWorld().equals(sift)) return;
        if (rnd.nextDouble() > plugin.getConfig().getDouble("spawning.new-chunk-group-chance", 0.025)) return;
        int bx = (e.getChunk().getX() << 4) + 8, bz = (e.getChunk().getZ() << 4) + 8;
        // weights from the_sift:sift_wastes biome JSON: echo_golem 1 (x1), sniffer 3 (x2-3), blub 3 (x1-3)
        int r = rnd.nextInt(7);
        Bukkit.getScheduler().runTask(plugin, () -> {
            int y = sift.getHighestBlockYAt(bx, bz) + 1;
            Location l = new Location(sift, bx + 0.5, y, bz + 0.5);
            if (r < 1) spawn("echo_golem", l);
            else if (r < 4) for (int i = 0; i < 2 + rnd.nextInt(2); i++) sift.spawnEntity(l, EntityType.SNIFFER);
            else for (int i = 0; i < 1 + rnd.nextInt(3); i++) spawn("blub", l);
        });
    }

    private long countNear(World w, Location l, String key, double r) {
        return w.getNearbyEntities(l, r, r, r).stream().filter(x -> key.equals(keyOf(x))).count();
    }

    private void naturalSpawns() {
        World sift = plugin.siftWorld();
        if (sift == null) return;
        var c = plugin.getConfig();
        double min = c.getDouble("spawning.min-radius", 48), max = c.getDouble("spawning.max-radius", 96);
        for (Player p : sift.getPlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR) continue;
            if (countNear(sift, p.getLocation(), "sifter", 128) < c.getInt("spawning.sifter-cap-per-player", 4)
                    && rnd.nextDouble() < c.getDouble("spawning.sifter-chance", 0.5)) {
                Location l = findSpawn(p, min, max, true);
                if (l != null) spawn("sifter", l);
            }
            if (rnd.nextDouble() < 0.02) {
                double spacing = c.getDouble("spawning.echo-golem-min-spacing", 165);
                if (countNear(sift, p.getLocation(), "echo_golem", spacing) == 0) {
                    Location l = findSpawn(p, min, max, false);
                    if (l != null) spawn("echo_golem", l);
                }
            }
        }
    }

    private Location findSpawn(Player p, double min, double max, boolean dark) {
        World w = p.getWorld();
        for (int attempt = 0; attempt < 8; attempt++) {
            double ang = rnd.nextDouble() * Math.PI * 2, dist = min + rnd.nextDouble() * (max - min);
            int x = (int) (p.getLocation().getX() + Math.cos(ang) * dist), z = (int) (p.getLocation().getZ() + Math.sin(ang) * dist);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
            int cy = dark ? p.getLocation().getBlockY() + rnd.nextInt(25) - 12 : w.getHighestBlockYAt(x, z) + 1;
            for (int dy = 0; dy < (dark ? 25 : 1); dy++) {
                int y = dark ? Math.max(w.getMinHeight() + 6, Math.min(w.getMaxHeight() - 4, cy + dy - 12)) : cy;
                Block feet = w.getBlockAt(x, y, z);
                if (!feet.isPassable() || !feet.getRelative(0, 1, 0).isPassable() || !feet.getRelative(0, -1, 0).getType().isSolid() || feet.isLiquid()) continue;
                if (dark && feet.getLightLevel() > 7) continue;
                return feet.getLocation().add(0.5, 0, 0.5);
            }
        }
        return null;
    }
}
