package dev.sift.portal;

import dev.sift.SiftPlugin;
import dev.sift.world.BlockPalette;
import dev.sift.world.StructureLoader;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Orientable;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPortalEnterEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Overworld portal: a frame of Reinforced Deepslate is lit by playing the Sonorous Deepslate note sequence
 * (1 3 7 6 5 2 4 8 opens, reversed closes) - taken from SonorousConsoles.TARGET_SEQUENCE in the original mod.
 * Portal interiors are vanilla nether_portal blocks that are tracked by this plugin and teleport to the Sift.
 */
public final class PortalManager implements Listener {
    private record PKey(UUID w, int x, int y, int z) {}
    private record Frame(Axis axis, List<Block> interior) {}

    private final SiftPlugin plugin;
    private final BlockPalette palette;
    private final StructureLoader structures;
    private final Map<PKey, Axis> portalBlocks = new HashMap<>();
    private final Map<String, Deque<long[]>> buffers = new HashMap<>();
    private final Map<UUID, Long> cooldown = new HashMap<>();
    private final File dataFile;
    private YamlConfiguration data;
    private int[] target;
    private int[] closing;
    private Material frameMat;
    private int radius, maxInterior, noteTimeout, cooldownTicks;

    public PortalManager(SiftPlugin plugin, BlockPalette palette, StructureLoader structures) {
        this.plugin = plugin; this.palette = palette; this.structures = structures;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        reloadConfig();
    }

    public void reloadConfig() {
        var c = plugin.getConfig();
        List<Integer> seq = c.getIntegerList("portal.note-sequence");
        target = seq.stream().mapToInt(Integer::intValue).toArray();
        closing = new int[target.length];
        for (int i = 0; i < target.length; i++) closing[i] = target[target.length - 1 - i];
        frameMat = Material.matchMaterial(c.getString("portal.frame-block", "REINFORCED_DEEPSLATE"));
        if (frameMat == null) frameMat = Material.REINFORCED_DEEPSLATE;
        radius = c.getInt("portal.search-radius", 10);
        maxInterior = c.getInt("portal.max-interior", 23);
        noteTimeout = c.getInt("portal.note-timeout-ticks", 100);
        cooldownTicks = c.getInt("portal.cooldown-ticks", 100);
    }

    public void start() {
        data = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : data.getStringList("portals")) {
            String[] t = s.split(";");
            portalBlocks.put(new PKey(UUID.fromString(t[0]), Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3])),
                    Axis.valueOf(t[4]));
        }
        // vanilla nether portals drop themselves when they have no obsidian frame; keep ours alive while a frame exists
        new BukkitRunnable() { @Override public void run() { restore(); } }.runTaskTimer(plugin, 40L, 40L);
    }

    private void save() {
        List<String> l = new ArrayList<>();
        portalBlocks.forEach((k, v) -> l.add(k.w() + ";" + k.x() + ";" + k.y() + ";" + k.z() + ";" + v.name()));
        data.set("portals", l);
        try { data.save(dataFile); } catch (IOException e) { plugin.getLogger().warning("data.yml: " + e); }
    }

    private static PKey key(Block b) { return new PKey(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ()); }
    private boolean isPortal(Block b) { return portalBlocks.containsKey(key(b)); }

    private Orientable portalData(Axis a) {
        Orientable o = (Orientable) Bukkit.createBlockData(Material.NETHER_PORTAL);
        o.setAxis(a);
        return o;
    }

    private void restore() {
        boolean changed = false;
        for (Iterator<Map.Entry<PKey, Axis>> it = portalBlocks.entrySet().iterator(); it.hasNext(); ) {
            var e = it.next(); PKey k = e.getKey();
            World w = Bukkit.getWorld(k.w());
            if (w == null || !w.isChunkLoaded(k.x() >> 4, k.z() >> 4)) continue;
            Block b = w.getBlockAt(k.x(), k.y(), k.z());
            if (b.getType() == Material.NETHER_PORTAL) continue;
            if (!hasFrameNeighbour(b, e.getValue())) { it.remove(); changed = true; continue; }
            b.setBlockData(portalData(e.getValue()), false);
        }
        if (changed) save();
    }

    private boolean hasFrameNeighbour(Block b, Axis axis) {
        for (BlockFace f : planeFaces(axis)) {
            Block n = b.getRelative(f);
            if (!n.getType().isAir() && !isPortal(n)) return true;
        }
        return false;
    }

    private static BlockFace[] planeFaces(Axis a) {
        return a == Axis.X ? new BlockFace[]{BlockFace.EAST, BlockFace.WEST, BlockFace.UP, BlockFace.DOWN}
                           : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.UP, BlockFace.DOWN};
    }

    // ---------------------------------------------------------------- Sonorous Deepslate consoles
    private NamespacedKey noteKey(Block b) { return new NamespacedKey(plugin, "n" + b.getX() + "_" + b.getY() + "_" + b.getZ()); }

    private int getNote(Block b) {
        Integer n = b.getChunk().getPersistentDataContainer().get(noteKey(b), PersistentDataType.INTEGER);
        return n == null ? 1 : n;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        String id = palette.idOf(b.getBlockData());
        if (id == null || !id.startsWith("sonorous_deepslate")) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        int note = getNote(b);
        if (p.isSneaking()) {           // sneak + use = tune the console (1..8) without playing it
            note = note % 8 + 1;
            b.getChunk().getPersistentDataContainer().set(noteKey(b), PersistentDataType.INTEGER, note);
            p.sendActionBar(net.kyori.adventure.text.Component.text("Note " + note));
            return;
        }
        Location at = b.getLocation().add(0.5, 0.5, 0.5);
        b.getWorld().playSound(at, "the_sift:block.sonorous_deepslate.sound_" + note, SoundCategory.BLOCKS, 1f, 1f);
        onNotePlayed(b, note);
    }

    private void onNotePlayed(Block b, int note) {
        String gk = b.getWorld().getUID() + ":" + anchor(b);
        Deque<long[]> buf = buffers.computeIfAbsent(gk, k -> new ArrayDeque<>());
        long now = Bukkit.getCurrentTick();
        buf.removeIf(n -> now - n[1] > noteTimeout);
        buf.addLast(new long[]{note, now});
        while (buf.size() > target.length) buf.removeFirst();
        if (buf.size() == target.length) {
            int[] seq = buf.stream().mapToInt(n -> (int) n[0]).toArray();
            if (Arrays.equals(seq, target)) { buf.clear(); open(b); }
            else if (Arrays.equals(seq, closing)) { buf.clear(); close(b); }
        }
    }

    /** Group anchor = lowest Sonorous Deepslate within 16 blocks (consoles of one portal share a buffer). */
    private String anchor(Block origin) {
        Block best = origin;
        for (int dx = -16; dx <= 16; dx++) for (int dy = -16; dy <= 16; dy++) for (int dz = -16; dz <= 16; dz++) {
            Block n = origin.getRelative(dx, dy, dz);
            if (n.getType() != Material.NOTE_BLOCK) continue;
            String id = palette.idOf(n.getBlockData());
            if (id == null || !id.startsWith("sonorous_deepslate")) continue;
            if (n.getY() < best.getY() || (n.getY() == best.getY() && (n.getX() < best.getX() || (n.getX() == best.getX() && n.getZ() < best.getZ()))))
                best = n;
        }
        return best.getX() + "," + best.getY() + "," + best.getZ();
    }

    // ---------------------------------------------------------------- frame scanning
    private Optional<Frame> scan(Block center, boolean forClosing) {
        Set<PKey> tried = new HashSet<>();
        for (int dx = -radius; dx <= radius; dx++) for (int dy = -radius; dy <= radius; dy++) for (int dz = -radius; dz <= radius; dz++) {
            Block b = center.getRelative(dx, dy, dz);
            if (forClosing) {
                Axis ax = portalBlocks.get(key(b));
                if (ax == null || !tried.add(key(b))) continue;
                Frame f = flood(b, ax, true);
                if (f != null) return Optional.of(f);
            } else if (b.getType() == frameMat) {
                for (Axis ax : new Axis[]{Axis.X, Axis.Z})
                    for (BlockFace face : planeFaces(ax)) {
                        Block s = b.getRelative(face);
                        if (!s.getType().isAir() || !tried.add(key(s))) continue;
                        Frame f = flood(s, ax, false);
                        if (f != null) return Optional.of(f);
                    }
            }
        }
        return Optional.empty();
    }

    private Frame flood(Block seed, Axis axis, boolean closingMode) {
        Deque<Block> q = new ArrayDeque<>();
        Set<Block> seen = new HashSet<>();
        q.add(seed); seen.add(seed);
        int minH = Integer.MAX_VALUE, maxH = Integer.MIN_VALUE, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        while (!q.isEmpty()) {
            Block cur = q.poll();
            int h = axis == Axis.X ? cur.getX() : cur.getZ();
            minH = Math.min(minH, h); maxH = Math.max(maxH, h); minY = Math.min(minY, cur.getY()); maxY = Math.max(maxY, cur.getY());
            if (maxH - minH + 1 > maxInterior || maxY - minY + 1 > maxInterior) return null;
            for (BlockFace f : planeFaces(axis)) {
                Block n = cur.getRelative(f);
                if (seen.contains(n)) continue;
                boolean inside = closingMode ? isPortal(n) : n.getType().isAir();
                if (inside) { seen.add(n); q.add(n); }
                else if (!closingMode && n.getType() != frameMat) return null;
            }
        }
        return seen.size() >= 3 ? new Frame(axis, new ArrayList<>(seen)) : null;
    }

    // ---------------------------------------------------------------- open / close
    private Location centroid(List<Block> l) {
        double x = 0, y = 0, z = 0;
        for (Block b : l) { x += b.getX() + 0.5; y += b.getY() + 0.5; z += b.getZ() + 0.5; }
        return new Location(l.get(0).getWorld(), x / l.size(), y / l.size(), z / l.size());
    }

    private void open(Block origin) {
        scan(origin, false).ifPresent(f -> {
            Location c = centroid(f.interior());
            List<Block> order = new ArrayList<>(f.interior());
            order.sort(Comparator.comparingDouble((Block b) -> -b.getLocation().add(0.5, 0.5, 0.5).distanceSquared(c)));
            int batch = Math.max(1, order.size() / 20);
            c.getWorld().playSound(c, "the_sift:block.sift_portal.trigger", SoundCategory.BLOCKS, 1f, 1f);
            for (int i = 0; i < order.size(); i += batch) {
                final List<Block> part = order.subList(i, Math.min(order.size(), i + batch));
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    for (Block b : part) { b.setBlockData(portalData(f.axis()), false); portalBlocks.put(key(b), f.axis()); }
                    save();
                }, 2L * (i / batch));
            }
            c.getWorld().playSound(c, "the_sift:the_sift_portal_open", SoundCategory.BLOCKS, 1f, 1f);
        });
    }

    private void close(Block origin) {
        scan(origin, true).ifPresent(f -> {
            Location c = centroid(f.interior());
            List<Block> order = new ArrayList<>(f.interior());
            order.sort(Comparator.comparingDouble((Block b) -> b.getLocation().add(0.5, 0.5, 0.5).distanceSquared(c)));
            for (Block b : order) portalBlocks.remove(key(b));
            save();
            int batch = Math.max(1, order.size() / 20);
            for (int i = 0; i < order.size(); i += batch) {
                final List<Block> part = order.subList(i, Math.min(order.size(), i + batch));
                Bukkit.getScheduler().runTaskLater(plugin, () -> part.forEach(b -> b.setType(Material.AIR, false)), 2L * (i / batch));
            }
            c.getWorld().playSound(c, "the_sift:the_sift_portal_close", SoundCategory.BLOCKS, 1f, 1f);
        });
    }

    // ---------------------------------------------------------------- teleport
    @EventHandler
    public void onEnter(EntityPortalEnterEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Block b = e.getLocation().getBlock();
        if (!isPortal(b)) return;
        long now = Bukkit.getCurrentTick();
        if (now - cooldown.getOrDefault(p.getUniqueId(), -10000L) < cooldownTicks) return;
        cooldown.put(p.getUniqueId(), now);
        teleport(p);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onVanillaPortal(PlayerPortalEvent e) {
        Block b = e.getFrom().getBlock();
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++)
            if (isPortal(b.getRelative(dx, dy, dz))) { e.setCancelled(true); return; }
    }

    /** Overworld/any -> Sift, or Sift -> where the player came from. */
    public void teleport(Player p) {
        World sift = plugin.siftWorld();
        if (sift == null) { p.sendMessage(Component("The Sift is not loaded. Restart the server once after the datapack was generated.")); return; }
        if (p.getWorld().equals(sift)) { leave(p); return; }
        data.set("returns." + p.getUniqueId(), p.getLocation());
        try { data.save(dataFile); } catch (IOException ignored) { }
        arrival(sift).thenAccept(loc -> Bukkit.getScheduler().runTask(plugin, () -> {
            p.teleportAsync(loc);
            p.playSound(loc, "the_sift:sift_intro", SoundCategory.MASTER, 1f, 1f);
        }));
    }

    private static net.kyori.adventure.text.Component Component(String s) { return net.kyori.adventure.text.Component.text(s); }

    private void leave(Player p) {
        Location ret = data.getLocation("returns." + p.getUniqueId());
        if (ret == null || ret.getWorld() == null) ret = Bukkit.getWorlds().get(0).getSpawnLocation();
        p.teleportAsync(ret);
    }

    /** Builds the original main_portal structure on first use and returns a safe arrival point next to its portal. */
    private CompletableFuture<Location> arrival(World sift) {
        Location stored = data.getLocation("sift.arrival");
        if (stored != null && stored.getWorld() != null) return CompletableFuture.completedFuture(stored);
        CompletableFuture<Location> result = new CompletableFuture<>();
        List<Integer> origin = plugin.getConfig().getIntegerList("portal.main-portal-search-origin");
        int cx = origin.size() > 0 ? origin.get(0) : 0, cz = origin.size() > 1 ? origin.get(1) : 0;
        StructureLoader.Structure st = structures.load("main_portal");
        int ox = cx - st.sx() / 2, oz = cz - st.sz() / 2;
        List<CompletableFuture<Chunk>> fs = new ArrayList<>();
        for (int x = (ox >> 4) - 1; x <= (ox + st.sx()) >> 4; x++) for (int z = (oz >> 4) - 1; z <= (oz + st.sz()) >> 4; z++)
            fs.add(sift.getChunkAtAsync(x, z));
        CompletableFuture.allOf(fs.toArray(new CompletableFuture[0])).whenComplete((v, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
            try {
                for (var f : fs) f.join().addPluginChunkTicket(plugin);
                int surface = sift.getHighestBlockYAt(cx, cz);
                int baseY = Math.min(Math.max(sift.getMinHeight() + 1, surface - 4), sift.getMaxHeight() - st.sy() - 1);
                List<Location> cells = new ArrayList<>();
                structures.place(new Location(sift, ox, baseY, oz), st, (l, kind) -> cells.add(l));
                Axis axis = cells.stream().map(Location::getBlockX).distinct().count() == 1 ? Axis.Z : Axis.X;
                List<Block> blocks = new ArrayList<>();
                for (Location l : cells) {
                    Block b = l.getBlock();
                    b.setBlockData(portalData(axis), false);
                    portalBlocks.put(key(b), axis);
                    blocks.add(b);
                }
                Location arrive = safeNear(centroid(blocks), axis);
                data.set("sift.arrival", arrive);
                save();
                for (var f : fs) f.join().removePluginChunkTicket(plugin);
                result.complete(arrive);
            } catch (Throwable t) { plugin.getLogger().severe("Main portal generation failed: " + t); result.completeExceptionally(t); }
        }));
        return result;
    }

    private Location safeNear(Location c, Axis axis) {
        World w = c.getWorld();
        Location best = null; double bd = Double.MAX_VALUE;
        for (int dx = -6; dx <= 6; dx++) for (int dy = -4; dy <= 6; dy++) for (int dz = -6; dz <= 6; dz++) {
            // stay at least 2 blocks out of the portal plane so arrival does not instantly re-trigger it
            int perp = axis == Axis.Z ? dx : dz;
            if (Math.abs(perp) < 2) continue;
            Block feet = w.getBlockAt(c.getBlockX() + dx, c.getBlockY() + dy, c.getBlockZ() + dz);
            if (!feet.isPassable() || !feet.getRelative(BlockFace.UP).isPassable() || !feet.getRelative(BlockFace.DOWN).getType().isSolid()) continue;
            if (feet.isLiquid()) continue;
            double d = dx * dx + dy * dy + dz * dz;
            if (d < bd) { bd = d; best = feet.getLocation().add(0.5, 0, 0.5); }
        }
        if (best == null) best = c.clone().add(3, 0, 0);
        // face the portal
        best.setDirection(c.toVector().subtract(best.toVector()));
        return best;
    }
}
