package dev.sift.world;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.nexomc.nexo.api.NexoBlocks;
import dev.sift.SiftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;

import java.io.InputStreamReader;
import java.util.*;

/** Maps Nexo block ids (identical to the original mod's block names) to the real vanilla BlockData Nexo uses for them. */
public final class BlockPalette {
    private final SiftPlugin plugin;
    private final List<String> ids = new ArrayList<>();
    private final Map<String, BlockData> byId = new HashMap<>();
    private final Map<BlockData, String> byData = new HashMap<>();

    public BlockPalette(SiftPlugin plugin) {
        this.plugin = plugin;
        try (var in = new InputStreamReader(plugin.getResource("nexo_blocks.json"))) {
            JsonObject o = JsonParser.parseReader(in).getAsJsonObject();
            ids.addAll(o.keySet());
        } catch (Exception e) { throw new IllegalStateException("nexo_blocks.json missing", e); }
    }

    /** Asks Nexo to place every block once at a scratch position and records the resulting block states. */
    public boolean resolve() {
        byId.clear(); byData.clear();
        World w = Bukkit.getWorlds().get(0);
        Location loc = new Location(w, 8, w.getMaxHeight() - 2, 8);
        Block b = loc.getBlock();
        BlockData old = b.getBlockData();
        for (String id : ids) {
            try {
                NexoBlocks.place(id, loc);
                BlockData d = b.getBlockData();
                if (d.getMaterial() == Material.NOTE_BLOCK || d.getMaterial() == Material.TRIPWIRE) {
                    byId.put(id, d.clone());
                    byData.putIfAbsent(d.clone(), id);
                } else plugin.getLogger().warning("Nexo did not place block '" + id + "' (got " + d.getMaterial() + ")");
            } catch (Throwable t) {
                plugin.getLogger().warning("Failed to resolve Nexo block " + id + ": " + t);
            }
        }
        b.setBlockData(old, false);
        plugin.getLogger().info("Resolved " + byId.size() + "/" + ids.size() + " Nexo blocks.");
        return !byId.isEmpty();
    }

    public BlockData get(String id) { return byId.get(id); }
    public String idOf(BlockData d) { return d == null ? null : byData.get(d); }
    public Map<String, BlockData> all() { return byId; }
}
