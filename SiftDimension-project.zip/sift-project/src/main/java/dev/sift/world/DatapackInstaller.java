package dev.sift.world;

import com.google.gson.*;
import dev.sift.SiftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.block.data.BlockData;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/**
 * Writes the ported datapack (original worldgen JSON from the mod) into <main world>/datapacks.
 * Every the_sift:<block> reference is replaced by the exact vanilla block state Nexo uses for that block,
 * so the dimension generates Nexo blocks natively - no post-processing needed.
 */
public final class DatapackInstaller {
    public enum Result { UNCHANGED, WRITTEN }
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final SiftPlugin plugin;
    private final BlockPalette palette;

    public DatapackInstaller(SiftPlugin plugin, BlockPalette palette) { this.plugin = plugin; this.palette = palette; }

    public Result install() throws IOException {
        String main = Bukkit.getWorlds().get(0).getName();
        String rel = plugin.getConfig().getString("datapack-path", "{main}/datapacks/the_sift_port").replace("{main}", main);
        Path root = Bukkit.getWorldContainer().toPath().resolve(rel).normalize();
        String stamp = stamp();
        Path stampFile = root.resolve(".sift_stamp");
        if (Files.exists(stampFile) && Files.readString(stampFile).equals(stamp)) return Result.UNCHANGED;

        List<String> index;
        try (var r = new BufferedReader(new InputStreamReader(plugin.getResource("datapack_index.txt"), StandardCharsets.UTF_8))) {
            index = r.lines().filter(s -> !s.isBlank()).toList();
        }
        if (Files.exists(root)) deleteTree(root);
        for (String f : index) {
            Path out = root.resolve(f);
            Files.createDirectories(out.getParent());
            if (f.endsWith(".json")) {
                try (var in = new InputStreamReader(plugin.getResource("datapack_template/" + f), StandardCharsets.UTF_8)) {
                    JsonElement e = JsonParser.parseReader(in);
                    boolean isTag = f.contains("/tags/block/");
                    Files.writeString(out, GSON.toJson(isTag ? tag(e) : tx(e, null)));
                }
            } else {
                try (var in = plugin.getResource("datapack_template/" + f)) { Files.copy(in, out); }
            }
        }
        Files.writeString(stampFile, stamp);
        plugin.getLogger().info("Wrote datapack to " + root);
        return Result.WRITTEN;
    }

    private String stamp() {
        try {
            var md = MessageDigest.getInstance("SHA-256");
            new TreeMap<>(palette.all()).forEach((k, v) -> md.update((k + "=" + v.getAsString() + ";").getBytes(StandardCharsets.UTF_8)));
            md.update(plugin.getPluginMeta().getVersion().getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(md.digest());
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    private static void deleteTree(Path p) throws IOException {
        try (var s = Files.walk(p)) { for (Path x : s.sorted(Comparator.reverseOrder()).toList()) Files.delete(x); }
    }

    private static boolean onlyKeys(JsonObject o, String... keys) {
        return Set.of(keys).containsAll(o.keySet());
    }

    private JsonElement tx(JsonElement e, String key) {
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            String bk = o.has("Name") ? "Name" : o.has("id") ? "id" : null;
            if (bk != null && o.get(bk).isJsonPrimitive() && o.get(bk).getAsString().startsWith("the_sift:")
                    && onlyKeys(o, bk, "Properties")) return state(o.get(bk).getAsString().substring(9), bk);
            JsonObject r = new JsonObject();
            for (var en : o.entrySet()) r.add(en.getKey(), tx(en.getValue(), en.getKey()));
            return r;
        }
        if (e.isJsonArray()) {
            JsonArray a = new JsonArray();
            for (JsonElement x : e.getAsJsonArray()) a.add(tx(x, key));
            return a;
        }
        if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isString() && ("blocks".equals(key) || "block".equals(key))) {
            String v = e.getAsString();
            if (v.startsWith("the_sift:")) return new JsonPrimitive(materialOf(v.substring(9)));
        }
        return e;
    }

    private String materialOf(String id) {
        BlockData d = palette.get(id);
        return d == null ? "minecraft:air" : d.getMaterial().getKey().toString();
    }

    private JsonObject state(String id, String nameKey) {
        JsonObject o = new JsonObject();
        if (id.equals("ichor")) {   // custom fluid has no vanilla equivalent: water (the biome water colour is already Ichor-cyan)
            o.addProperty(nameKey, "minecraft:water");
            JsonObject p = new JsonObject(); p.addProperty("level", "0"); o.add("Properties", p);
            return o;
        }
        BlockData d = palette.get(id);
        if (d == null) { o.addProperty(nameKey, "minecraft:air"); return o; }
        String s = d.getAsString();   // minecraft:note_block[instrument=bass,note=3,powered=false]
        int br = s.indexOf('[');
        o.addProperty(nameKey, br < 0 ? s : s.substring(0, br));
        if (br >= 0) {
            JsonObject p = new JsonObject();
            for (String kv : s.substring(br + 1, s.length() - 1).split(",")) {
                String[] t = kv.split("=", 2);
                p.addProperty(t[0], t[1]);
            }
            o.add("Properties", p);
        }
        return o;
    }

    /** Block tags: custom block entries become their stand-in vanilla block (tags match by block type). */
    private JsonElement tag(JsonElement e) {
        JsonObject o = e.getAsJsonObject().deepCopy();
        if (o.has("values")) {
            LinkedHashSet<String> vals = new LinkedHashSet<>();
            for (JsonElement v : o.getAsJsonArray("values")) {
                String s = v.isJsonPrimitive() ? v.getAsString() : v.getAsJsonObject().get("id").getAsString();
                if (s.startsWith("the_sift:")) { String m = materialOf(s.substring(9)); if (!m.equals("minecraft:air")) vals.add(m); }
                else vals.add(s);
            }
            JsonArray a = new JsonArray(); vals.forEach(a::add); o.add("values", a);
        }
        return o;
    }
}
