package dev.sift.world;

import com.google.gson.*;
import dev.sift.SiftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;

import java.io.InputStreamReader;
import java.util.*;
import java.util.function.BiConsumer;

/** Loads the original structure NBTs (converted to JSON by tools/convert.py) and places them with Nexo blocks. */
public final class StructureLoader {
    public record Structure(int sx, int sy, int sz, String[] names, List<Map<String, String>> props, int[][] blocks) {}
    private final SiftPlugin plugin;
    private final BlockPalette palette;
    private final Map<String, Structure> cache = new HashMap<>();

    public StructureLoader(SiftPlugin plugin, BlockPalette palette) { this.plugin = plugin; this.palette = palette; }

    public Structure load(String name) {
        return cache.computeIfAbsent(name, n -> {
            try (var in = new InputStreamReader(plugin.getResource("structures/" + n + ".json"))) {
                JsonObject o = JsonParser.parseReader(in).getAsJsonObject();
                JsonArray sz = o.getAsJsonArray("size");
                JsonArray pal = o.getAsJsonArray("palette");
                String[] names = new String[pal.size()];
                List<Map<String, String>> props = new ArrayList<>();
                for (int i = 0; i < pal.size(); i++) {
                    JsonObject p = pal.get(i).getAsJsonObject();
                    names[i] = p.get("name").getAsString();
                    Map<String, String> m = new LinkedHashMap<>();
                    p.getAsJsonObject("props").entrySet().forEach(e -> m.put(e.getKey(), e.getValue().getAsString()));
                    props.add(m);
                }
                JsonArray bl = o.getAsJsonArray("blocks");
                int[][] blocks = new int[bl.size()][];
                for (int i = 0; i < bl.size(); i++) {
                    JsonArray b = bl.get(i).getAsJsonArray();
                    blocks[i] = new int[]{b.get(0).getAsInt(), b.get(1).getAsInt(), b.get(2).getAsInt(), b.get(3).getAsInt()};
                }
                return new Structure(sz.get(0).getAsInt(), sz.get(1).getAsInt(), sz.get(2).getAsInt(), names, props, blocks);
            } catch (Exception e) { throw new IllegalStateException("structure " + n, e); }
        });
    }

    /** Resolves a palette entry to BlockData; air for jigsaw/structure blocks and unknown blocks. */
    public BlockData resolve(Structure s, int palIdx) {
        String name = s.names[palIdx];
        Map<String, String> pr = s.props.get(palIdx);
        if (name.startsWith("the_sift:")) {
            BlockData d = palette.get(name.substring(9));
            return d != null ? d : Bukkit.createBlockData(Material.AIR);
        }
        if (name.equals("minecraft:jigsaw") || name.equals("minecraft:structure_void")) return Bukkit.createBlockData(Material.AIR);
        StringBuilder sb = new StringBuilder(name);
        if (!pr.isEmpty()) {
            sb.append('[');
            pr.forEach((k, v) -> sb.append(k).append('=').append(v).append(','));
            sb.setLength(sb.length() - 1);
            sb.append(']');
        }
        try { return Bukkit.createBlockData(sb.toString()); } catch (IllegalArgumentException ex) { return Bukkit.createBlockData(Material.AIR); }
    }

    /**
     * Places the structure with its minimum corner at {@code origin}. {@code portalCell} receives the world position of
     * every the_sift:sift_portal cell; the caller turns those into real portal blocks.
     */
    public void place(Location origin, Structure s, BiConsumer<Location, String> portalCell) {
        World w = origin.getWorld();
        for (int[] b : s.blocks) {
            String name = s.names[b[3]];
            Location l = origin.clone().add(b[0], b[1], b[2]);
            if (name.equals("the_sift:sift_portal")) { portalCell.accept(l, "portal"); continue; }
            if (name.equals("minecraft:structure_void")) continue;
            w.getBlockAt(l).setBlockData(resolve(s, b[3]), false);
        }
    }
}
