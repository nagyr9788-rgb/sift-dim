package dev.sift;

import dev.nexomc.nexo.api.NexoItems;
import dev.sift.mob.MobManager;
import dev.sift.portal.PortalManager;
import dev.sift.world.BlockPalette;
import dev.sift.world.DatapackInstaller;
import dev.sift.world.StructureLoader;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;

public final class SiftPlugin extends JavaPlugin {
    private BlockPalette palette;
    private StructureLoader structures;
    private PortalManager portals;
    private MobManager mobs;
    private YamlConfiguration mobConfig;
    private boolean ready;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "mobs.yml").exists()) saveResource("mobs.yml", false);
        getCommand("sift").setExecutor(new SiftCommand(this));
        getCommand("sift").setTabCompleter(new SiftCommand(this));
        // Nexo loads its items asynchronously after startup; wait for our ids to exist.
        new BukkitRunnable() {
            int tries = 0;
            @Override public void run() {
                tries++;
                if (NexoItems.exists("siftslate")) { cancel(); init(); }
                else if (tries > 120) {
                    cancel();
                    getLogger().severe("Nexo items 'siftslate' never appeared. Copy the project's nexo/ folder into plugins/Nexo/ and restart.");
                }
            }
        }.runTaskTimer(this, 20L, 20L);
    }

    private void init() {
        palette = new BlockPalette(this);
        if (!palette.resolve()) {
            getLogger().severe("Could not resolve Nexo block states. Is the Nexo block mechanic enabled?");
            return;
        }
        try {
            DatapackInstaller.Result r = new DatapackInstaller(this, palette).install();
            if (r == DatapackInstaller.Result.WRITTEN)
                getLogger().warning("The Sift datapack was (re)generated. RESTART THE SERVER once so the dimension loads.");
        } catch (IOException ex) {
            getLogger().severe("Datapack install failed: " + ex);
        }
        structures = new StructureLoader(this, palette);
        portals = new PortalManager(this, palette, structures);
        mobs = new MobManager(this);
        Bukkit.getPluginManager().registerEvents(portals, this);
        Bukkit.getPluginManager().registerEvents(mobs, this);
        portals.start();
        mobs.start();
        ready = true;
        if (siftWorld() == null)
            getLogger().warning("Dimension world not loaded yet (the_sift:the_sift). If you just installed, restart once.");
        else getLogger().info("The Sift dimension is loaded.");
    }

    public void reload() {
        reloadConfig();
        mobConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "mobs.yml"));
        if (ready) { palette.resolve(); mobs.reloadDefs(); portals.reloadConfig(); }
    }

    public YamlConfiguration mobConfig() {
        if (mobConfig == null) mobConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "mobs.yml"));
        return mobConfig;
    }

    public World siftWorld() {
        NamespacedKey k = NamespacedKey.fromString(getConfig().getString("dimension-key", "the_sift:the_sift"));
        World w = k == null ? null : Bukkit.getWorld(k);
        if (w == null) w = Bukkit.getWorld(getConfig().getString("dimension-world-name-fallback", "the_sift"));
        return w;
    }

    public boolean isReady() { return ready; }
    public BlockPalette palette() { return palette; }
    public StructureLoader structures() { return structures; }
    public PortalManager portals() { return portals; }
    public MobManager mobs() { return mobs; }
}
