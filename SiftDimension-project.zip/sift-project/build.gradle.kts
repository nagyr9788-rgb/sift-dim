plugins {
    java
    id("com.gradleup.shadow") version "8.3.5" apply false
}

group = "dev.sift"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
    maven("https://repo.nexomc.com/releases")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:${property("paperApiVersion")}")
    compileOnly("com.nexomc:nexo:${property("nexoVersion")}")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.processResources {
    filesMatching("plugin.yml") { expand("version" to project.version) }
}

// `gradle bundle` -> build/install/ with plugin jar + Nexo folder, ready to copy to the server
tasks.register<Copy>("bundle") {
    dependsOn(tasks.jar)
    into(layout.buildDirectory.dir("install"))
    from(tasks.jar) { into("plugins") }
    from("nexo") { into("plugins/Nexo") }
}
